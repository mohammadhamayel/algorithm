/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package huff;

/**
 *
 * @author Mphammad
 */
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class Huffman {
    String ext;
    int count;
    int[] freq = new int[256];
    Heap heap;
    int numOfChars;
        
        String[] ascii = new String[256];;        
        

        public Huffman() {
           
        }

        //Compressing the file
        public void compress(String path) {
                getFreq(path);
                generateTree(); 
                generateCode(heap.getMin(), "");        
                outFile(path, ascii);
        }

     
        public void getFreq(String path) {
                try {
                        readFreqsFromFile(path);                        
                }
                catch (FileNotFoundException ex) {
                        System.exit(0);
                }
                catch (IOException ex) {
                        ex.printStackTrace();
                }
        }

        
        private void readFreqsFromFile(String path)
        throws FileNotFoundException, IOException {
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(path));
                int byt = 0;
                count = 0;
                while ((byt = bis.read()) != -1) {
                        freq[byt] = freq[byt] + 1;
                        count ++;
                }
                bis.close();
        }

       
        private void generateTree() {
                createHeap(freq);
                numOfChars = heap.getSize();
                heap = createTree(heap);        
        }

      
        private void createHeap(int[] freq) {
                heap = new Heap(257);
                for(int i = 0; i < freq.length; ++i) {
                        if(freq[i] != 0) {
                                Node node = new Node(freq[i], i);
                                node.setToLeaf();
                                heap.insert(node);
                        }
                }
        }

        private Heap createTree(Heap heap) {
                int n = heap.getSize();
                for(int i = 0; i < (n-1); ++i) {
                        Node z = new Node();
                        z.setLeft(heap.delMin());
                        z.setRight(heap.delMin());
                        z.setFreq(z.getLeft().getFreq() + z.getRight().getFreq());
                        heap.insert(z);
                }
                return heap;
        }

        private void generateCode(Node node, String code) {             
                if(node != null) {                      
                        if(node.isLeaf())
                                ascii[node.getValue()] = code;
                        else {
                                generateCode(node.getLeft(), code + "0");
                                generateCode(node.getRight(), code + "1");
                        }
                }
        }

      
        private void outFile(String path, String[] ascii) {
                try {
                        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(path));
                        path = path + ".huff";
                        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(path));
                        writeHeader(bos);
                        writeBody(bos, bis);
                        bos.close();
                }
                catch(Exception e) {
                        System.out.println(e);
                }
        }

      
        private void writeHeader(BufferedOutputStream bos)
        throws IOException {
                bos.write(numOfChars);
                writeFullInt(bos, count);
                writeFreqs(bos);
        }

       
        private void writeFreqs(BufferedOutputStream bos) throws IOException {
                for (int i = 0; i < ascii.length; ++i) {
                        if(ascii[i] != null) {
                                bos.write(i);
                                writeFullInt(bos, freq[i]);
                        }
                }
        }

        
        private void writeBody(BufferedOutputStream bos, BufferedInputStream bis) 
        throws IOException {
                String buffer = writeBodyText(bos, bis);
                writeRemainingBuffer(bos, buffer);
        }

        private String writeBodyText(BufferedOutputStream bos,
                        BufferedInputStream bis)
        throws IOException {
                String buffer = "";
                boolean[] bits = new boolean[8];
                int byteRead;
                int byteToWrite = 0;

                while ((byteRead = bis.read()) != -1) {
                        String charToWrite = ascii[byteRead];             
                        buffer = buffer + charToWrite;
                        while(buffer.length() >= 8) {   
                                for(int i = 0; i < 8; ++i) {
                                        if(buffer.charAt(i) == '1') 
                                                bits[i] = true;
                                        else
                                                bits[i] = false;
                                }
                                buffer = buffer.substring(8);
                                byteToWrite = bitsToByte(bits);
                                bos.write(byteToWrite);
                        }                       
                }
                return buffer;
                
        }

       
        private void writeRemainingBuffer(BufferedOutputStream bos, String buffer) throws IOException {
                boolean[] bits = new boolean[8];
                int byteToWrite;
                if(buffer.length() > 0) {
                        int difference = 8 - buffer.length();
                        for(int i = 0; i < buffer.length(); ++i) {
                                if(i > difference) {
                                        bits[i] = false;
                                }
                                else {
                                        if(buffer.charAt(i) == '1')
                                                bits[i] = true;
                                        else
                                                bits[i] = false;
                                }
                        }
                }
                byteToWrite = bitsToByte(bits);
                bos.write(byteToWrite);
        }

      
       
        public void extract(String path) {
                try {
                        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(path));           
                        String outPutpath = path.substring(0, path.length()-5); // remove .huff from the name
                        BufferedOutputStream bos = 
                                new BufferedOutputStream(new FileOutputStream(outPutpath));
                        numOfChars = bis.read();
                        count = readFullLengthInt(bis);
                        readSymbols(bis);
                        generateTree();
                        writeCompressedFile(bis, bos);
                }
                catch(Exception e){
                        System.out.println("File not found");
                        System.exit(0);
                }
        }

     
        private void readSymbols(BufferedInputStream bis)
        throws IOException {
                ascii = new String[256];
                for(int i = 0; i < numOfChars; ++i) {                              
                        int character = bis.read();
                        freq[character] = readFullLengthInt(bis);
                }
        }

     
        private void writeCompressedFile(BufferedInputStream bis,
                        BufferedOutputStream bos) throws IOException {
                Node node = heap.getMin();
                int value;
                int character;
                while(true) {
                        character = bis.read();
                        for(int i = 0; i < 8; ++i) {
                                if(node.isLeaf()) {
                                        value = node.getValue();
                                        bos.write(value);
                                        node = heap.getMin();
                                        count--;
                                        if(count == 0) {
                                                break;
                                        }
                                }
                                int bit = (character & 0x80);                   
                                if(bit == 0x80) {
                                        node = node.getRight();
                                }
                                else
                                        node = node.getLeft();
                                character <<= 1;
                        }
                        if(count == 0) {
                                break;
                        }
                }
                bos.close();
        }

        public String getCharectersFreq(){
            String numOfFreqChar= "";
            String s;
for (int i=0; i<256; i++){
            
            if(freq[i] != 0){
                s = String.valueOf((char)(i));
                numOfFreqChar+=s  + ": "+ freq[i]+ "   ";
            }
        }
return numOfFreqChar;
        }
        
        public  void writeFullInt(BufferedOutputStream bos, int integer) throws IOException {
                String hexRepresentation = Integer.toHexString(integer);
                String hex = "";
                for(int i = 0; i < 8 - hexRepresentation.length(); ++i) {
                        hex = hex + "0";                
                }
                hex = hex + hexRepresentation;
                for(int i = 0; i < 4; ++i) {
                        String byteToWrite = hex.substring(0, 2);
                        bos.write(Integer.parseInt(byteToWrite, 16));
                        hex = hex.substring(2);
                }
        }

       
        public  int readFullLengthInt(BufferedInputStream bis) throws IOException {
                int integer = 0;
                for(int i = 0; i < 4; ++i) {
                        int byteRead = bis.read();
                        for(int j = 0; j < 8; ++j) {
                                int bit = (byteRead & 0x80);
                                if(bit == 0x80) {
                                        integer <<= 1;
                                        integer += 1;
                                }
                                else {
                                        integer <<= 1;
                                }
                                byteRead <<= 1;
                        }
                }
                return integer;
        }

      
        public  int bitsToByte(boolean[] bits) {
                if (bits == null || bits.length != 8) {
                        throw new IllegalArgumentException();
                }
                int data = 0;
                for (int i = 0; i < 8; i++) {
                        if (bits[i]) data += (1 << (7-i));
                }
                return data;
        }

      
        
        public  boolean[] byteToBits(int data) {
                if (data < 0 || 255 < data) {
                        throw new IllegalArgumentException("" + data);
                }
                boolean[] bits = new boolean[8];
                for (int i=0; i < 8; i++) {
                        bits[i] = ( (data & (1 << (7-i)) ) != 0 );
                }
                return bits;
        }
        
        
        
     
}