package huffm;
public class PriorityQueue
{
  private Node head;
  private Node tail;
  private int mySize = 0;
  private int capacity;
  public PriorityQueue()
  {
    this(3000);
  }
 public PriorityQueue(int capacity)
  {
    this.head = new Node();
    this.tail = new Node();
    head.setNext(tail);
    tail.setPrevious(head);
    this.capacity = capacity;
  }
  public void add(HuffNode myHuffNode)throws HuffmanExeption
  {
    if (mySize == capacity)
      throw new HuffmanExeption(" FULL ERROR ");
    if (hasNoNode())
    {

      //insert new node to queue
      Node node = new Node(tail, head, myHuffNode);
      head.setNext(node);
      tail.setPrevious(node);
    }
    else
    {

        //get the node next to head
        Node node = head.getNext();

        //get the occurence of character
        int key = myHuffNode.getFrequency();
        /**
         * after on go inside while one given huffman node will be inserted
         * sortedly
         */
        while (true)
        {

          // Sort the nodes according to frequencies
          if (node.getElement().getFrequency() > key)
          {
            Node second = node.getPrevious();
            Node huf = new Node(node, second, myHuffNode);
            second.setNext(huf);
            node.setPrevious(huf);
            break;
          }
          if (node.getNext() == tail)
          {
            Node huf = new Node(tail, node, myHuffNode);
            node.setNext(huf);
            tail.setPrevious(huf);
            break;
          }
          node = node.getNext();
         } //end while
        }
        //size of queue incremented once
        mySize++;
  }
 public boolean hasNoNode()
  {
    return (head.getNext() == tail);
  }
 public HuffNode remove() throws HuffmanExeption
 {
   if(isEmpty())
     throw new HuffmanExeption("Priority Queue is empty");

    HuffNode huff = head.getNext().getElement();
    Node sec = head.getNext().getNext();
    head.setNext(sec);
    sec.setPrevious(head);
    mySize--;
    return huff;
  }
 public HuffNode peek()throws Exception
  {
    if(isEmpty())
     throw new Exception("Queue is empty");

    HuffNode huff = head.getNext().getElement();
    return huff;
  }
  public boolean isEmpty()
  {
    if(mySize == 0)
      return true;
    return false;
  }
  public int size()
  {
    return mySize;
  }
}
