package huffm;



import java.io.*;
import javax.swing.*;

public class Compressor implements HuffConstants
{
  private static String code[], huffReport="";
  private int totalBytes = 0;
  private int count = 0;
  private File inputFile;
  private File outputFile ;
  private FileOutputStream C;
  private ObjectOutputStream outF;
  private BufferedOutputStream bOutStream;
  private FileInputStream fileInputStream;
  private BufferedInputStream in;
  private boolean succesful = false;
  PriorityQueue pQueue = new PriorityQueue();
  public  Compressor(File inputFile)
  {
    this.inputFile = inputFile;//the file you will compress it
  }
  public void compress()
  {

    int freq[] = new int[DIFF_BYTES];
    for(int i = 0; i < DIFF_BYTES; i++)//to find the freq of char in the file
    {
      freq[i] = 0;
    }

  try
  {
    fileInputStream = new FileInputStream(inputFile);
    in = new BufferedInputStream(fileInputStream);
  }
  catch(Exception e)
  {
    System.out.println("Error "+e.getMessage());
  }
  try
  {

    totalBytes = in.available();//return the num of byte that read from inp

    int mycount = 0;
    in.mark(totalBytes);// Marks the current position in this input stream
    while (mycount < totalBytes)//to find how many every byte is repeat
    {
      int a = in.read();
      mycount++;
      freq[a]++;
      //System.out.println("a = "+a+"freq[a] in count "+mycount+" = "+freq[a]);
    }
    in.reset(); // Repositions this stream to the position at the time the mark method was last called on this input stream.
  }
  catch(IOException ex)
  {
    System.out.println("error");
  }

  HuffNode tree = new HuffNode();
  HuffNode first = new HuffNode();
  HuffNode second = new HuffNode();
  try
  {
    for(int i = 0; i < DIFF_BYTES; i++)// to create hffnode(each value ,withe it frequency )
    {
    if (freq[i] > 0)
    {
      HuffNode t = new HuffNode( freq[i], i, null, null, null);
      pQueue.add(t);
    }
  }

  while (pQueue.size() > 1)//create the huffman tree
  {
    first = pQueue.remove();
    second = pQueue.remove();
    int f1 = first.getFrequency();
    int f2 = second.getFrequency();
    if (f1 > f2)
    {
      HuffNode t = new HuffNode((f1 + f2), 0, second, first, null);
      //HuffNode(int frequency,int value,HuffNode left,HuffNode right,HuffNode parent)
      first.parent = t;
      second.parent = t;
      pQueue.add(t);
    }
    else
    {
        HuffNode t = new HuffNode( (f1 + f2), 0, first, second, null);
        first.parent = t;
        second.parent = t;
        pQueue.add(t);
    }
  } //end while

  tree = pQueue.remove();
  }//end try
  catch(Exception e)
  {
    System.out.println(" Priority Queue error ");
  }

  code = new String[DIFF_BYTES];//initialize code ""
  for(int i = 0; i < DIFF_BYTES; i++)
    code[ i ] = "";
  traverse(tree);//do traversal for tree give code for every hffnode ,and save it in arry code
  Table rec = new Table(totalBytes, inputFile.getName());// you give the size and the name of tabel
  for(int i = 0; i < DIFF_BYTES; i++)// copy the amount of freq to the arry which it in table
  {
    rec.push(freq[i]);
    if(freq[i] == 0)
      continue;
  }

 int wrote=0, csize=0;
 int  recordLast=0;
 try
 {
   outputFile = new File(inputFile.getName()+".huf");//to write into file output
   C = new FileOutputStream(outputFile);//to write into file output by FileOutputStream
   outF = new ObjectOutputStream(C);
   bOutStream = new BufferedOutputStream(C);
   outF.writeObject(rec);// to writ object (table) which contain file name and it siz and frequency for each char into file ((((((((((wwwwwwwrite header))))))))))
   String outbyte="";

   while (count < totalBytes)
   {
     outbyte += code[in.read()];//add the code for each freqyency to the string outbyte
     count++;
     if (outbyte.length() >= BITS_PER_BYTES)// frequency iz more than 8 (if it was freeqenc more than monce)
     {
       int k = toInt(outbyte.substring(0, BITS_PER_BYTES));
       csize++;
       bOutStream.write(k);// writ k in integer into file
       outbyte = outbyte.substring(BITS_PER_BYTES); //set the string outbyte
     }
   }//end while
   while(outbyte.length() > BITS_PER_BYTES)
   {
     csize++;
     int k = toInt(outbyte.substring(0,BITS_PER_BYTES));
     bOutStream.write(k);
     outbyte = outbyte.substring(BITS_PER_BYTES);
   }

   if((recordLast=outbyte.length()) > 0)// while outbyte not zero
   {
     while(outbyte.length() < BITS_PER_BYTES)// while outbyte less than 8 bit
       outbyte += 0;
     //System.out.println(outbyte);
     bOutStream.write(toInt(outbyte));
     csize++;
   }
   bOutStream.write(recordLast);// writ recod list (length of outbyte ) into file
   bOutStream.close();
 }
 catch(Exception ex)
 {
   System.out.println("Error in writng "+ex.getMessage());
 }
 float compressionRatio =1-( (float) csize/((float)totalBytes));
 huffReport+="File name : "+ inputFile.getName();
 huffReport+="\n";
 huffReport+="File size : "+totalBytes+" bytes.";
 huffReport+="\n";
 huffReport+="Compressed size : "+ csize+" bytes.";
 huffReport+="\n";
 huffReport+="Compression ratio: "+(compressionRatio*100)+" %";
 huffReport+="\n";
 succesful = true;
 }
  private  void traverse(HuffNode n)// to give the every element(huffnode) code and save it in arry code
  {
    if (n.isLeaf())
    {
      HuffNode m = n;
      int arr[] = new int[20],p=0;
      while (true)
      {
        if (m.parent.left==m)// if the node was left
          arr[p]=0;
        else// if it was right
            arr[p]=1;
        p++;
        m=m.parent;
        if(m.parent==null)// it finish the tree
          break;
      }
      for(int j = p-1; j >= 0; j--)
        code[n.getValue()] += arr[j];// to save the code for every element in code arry
    } //end if isleaf
    if(n.left != null)
      traverse(n.left);
    if(n.right!=null)
      traverse(n.right);
  }

 private int toInt(String b)
  {
    int output = 0,wg = 128;
    for(int i = 0; i < BITS_PER_BYTES; i++)
    {
      output += wg*Integer.parseInt(""+b.charAt(i));// to turn the amount of string ( it int store in string) to int
      // and return it from binary to int
      wg /= 2;// power 2^n
    }
    return output;
  }
  public int lengthOftask()
  {
    return totalBytes;// num of bute
  }
  public int getCurrent()
  {
    return count;//num of char which we worked in it
  }
  public String gethuffReport()
  {
    String temp=huffReport;
    huffReport="";
    return temp;
  }
  public boolean issuccesful()
  {
    return succesful;
  }
}

