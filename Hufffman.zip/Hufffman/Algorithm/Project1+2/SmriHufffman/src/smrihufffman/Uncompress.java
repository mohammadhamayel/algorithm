package huffm;
import java.io.*;
import javax.swing.*;
public class Uncompress implements HuffConstants
{
  private int totalBytes = 0;
  private int mycount = 0;//num of all character
  private int freq[];
  private int array = 0;
  private String huffReport="";
  private File inputFile;
  private Table table;
  private FileInputStream in1;
  private ObjectInputStream inF;
  private BufferedInputStream in;
  private File outputFile ;
  private FileOutputStream outf;
  public Uncompress(File file)
  {
    inputFile = file;//the file which we will uncompress
  }

  public void decompress()throws HuffmanExeption
  {
    freq = new int[DIFF_BYTES ];
    for(int i = 0; i < DIFF_BYTES; i++)//intial the the array freq
    {
      freq[i] = 0;
    }
    try
    {
      in1 = new FileInputStream(inputFile);
      inF = new ObjectInputStream(in1);
      in = new 	BufferedInputStream(in1);
      table = (Table) (inF.readObject());// to read the header from compress file
      outputFile = new File(table.fileName());//give the orginal name of file ( which save into compress file) to new file
      outf = new FileOutputStream(outputFile);
      huffReport += "File name : " + table.fileName();
      huffReport += "\n";
    }
    catch(Exception ex)// if it wasn't compress by my programme
    {
      JOptionPane.showMessageDialog(null,"Error"+"\nNot a valid  huf  format file.",
                                    "Report",JOptionPane.INFORMATION_MESSAGE);
      System.exit(0);
    }

    HuffNode tree = new HuffNode();
    HuffNode first = new HuffNode();
    HuffNode second = new HuffNode();
    PriorityQueue pQueue = new PriorityQueue();
    try
    {

      for(int j = 0;j < DIFF_BYTES ; j++)//to build huffnode contain value and it its frequncy
      {
        int r = table.pop();//the amount of frequncy for value j
        if (r > 0)
        {
          HuffNode t = new HuffNode(r, j, null, null, null);
          pQueue.add(t);
        }
      }

      //create tree
      while (pQueue.size() > 1)//creat tree
      {
        first = pQueue.remove();
        second = pQueue.remove();
        int f1 = first.getFrequency();
        int f2 =second.getFrequency();
        if (f1 > f2)//the small frequency to the left
        {
          HuffNode t = new HuffNode((f1+f2), 0,second, first, null);
          first.parent = t;
          second.parent = t;
          pQueue.add(t);
        }
        else
        {
            HuffNode t = new HuffNode((f1+f2), 0, first,second, null);
            first.parent = t;
            second.parent = t;
            pQueue.add( t );
        }

      }
      tree = pQueue.remove();
    }
    catch(HuffmanExeption ex)
    {
      System.out.println(" Priority queue exception "+ex.getMsg());
    }

    String s="";//it will has binary value and we will work in it
    try
    {
      mycount = in.available();//to get the num of all character in file
      while (totalBytes < mycount)
      {
        array = in.read();
        s += toBinary(array);
        //System.out.println("s = "+s);
        while (s.length() > 32)
        {
          for(int a = 0; a < 32; a++)
          {
            int wr = getCode(tree, s.substring(0, a+1));//tree whith code
            if(wr == -1)
              continue;
            else
            {
                outf.write(wr);//writ wr (value of node) into file
                s = s.substring(a + 1);
                break;
            }
          }
        }
        totalBytes++;
      }
      s = s.substring(0, (s.length() - BITS_PER_BYTES));
      s = s.substring(0, (s.length() - BITS_PER_BYTES + array));
      int counter;
      while (s.length() > 0)
      {
        if(s.length( ) > 16)
          counter = 16;//cause we was add extra char when we composse
        else
          counter = s.length();
        for(int a = 0; a < counter; a++)
        {
          int wr = getCode(tree, s.substring(0, a + 1));
          if(wr == -1)
            continue;
          else
          {
              outf.write(wr);
              s = s.substring(a + 1);
              break;
          }
        }
      }
      outf.close();
    }
    catch(IOException ex)
    {
      System.out.println(ex.getMessage());
    }
    huffReport += "Compressed size : "+ mycount+" bytes.";
    huffReport +="\n";

    huffReport +="Size after decompressed : "+table.originalSize()+" bytes.";
    huffReport +="\n";
  }
  private int getCode(HuffNode node, String decode)
  {
    while (true)
    {
      if (decode.charAt(0)=='0')//it mean if the num of decode = it mean that node is at left
        node = node.left;
      else
          node = node.right;

      if (node.isLeaf())// if it waz (has value and frequency) is leaf
        return node.getValue();

      if(decode.length() == 1)
        break;
      decode = decode.substring(1);
    }
    return -1;
  }
  public  String toBinary(int b)
  {
    int arr[] = new int[BITS_PER_BYTES];//to store of(bawake elksma :P)
    String s ="";
    for(int i = 0; i < BITS_PER_BYTES; i++)
    {
      arr[i] = b % 2;
      b /= 2;

    }
    for(int i = 7; i >= 0; i--)
    {
      s += arr[i];//to get the binary
    }
    return s;
  }
  public int toInt(String b)
  {
    int output = 0;
    int wg = 128;
    for(int i = 0; i < BITS_PER_BYTES; i++)
    {
      output += wg*Integer.parseInt("" + b.charAt(i));
      wg /= 2;
    }
    return output;
  }
  public int getCurrent()
  {
    return totalBytes;//num of byte we work at
  }
  public int lengthOftask()
  {
    return mycount;// size of file
  }
  public String gethuffReport()
  {
    return huffReport;
  }
}