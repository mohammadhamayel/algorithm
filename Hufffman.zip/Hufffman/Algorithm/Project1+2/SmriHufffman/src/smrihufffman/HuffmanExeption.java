package huffm;
public class HuffmanExeption extends Exception
{
  private String msg;
  public HuffmanExeption()
  {
    super("Huffman Exception");
  }
  public HuffmanExeption(String msg)
  {
     super(msg);
     this.msg = msg;
  }
  public String getMsg()
  {
     return msg;
  }
}