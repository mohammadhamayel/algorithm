package huffm;


public interface HuffConstants
{
  public static final int BITS_PER_BYTES = 8;
  public static final int DIFF_BYTES = 256;
}
