package huffm;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.BevelBorder;

public class MainHuffman extends JFrame {
	private File file1;
	private File file2;
	private Compressor compress;
	private Uncompress uncompress;
	// Button to enable compression and uncompression
	private JButton comp, uncomp;
	private JFileChooser choose = new JFileChooser();
	private JMenuItem compressMenuItem, uncompressMenuItem;
	private JLabel statusBar;
	private boolean exists;
	private String copy;

	public MainHuffman() {
		super("HUFFMAN CODE");
		JMenuBar menuBar = createMenuBar();
		setJMenuBar(menuBar);
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add("East", comp = new JButton("Compress"));
		p.add("West", uncomp = new JButton("Uncompress"));
		JPanel p2 = new JPanel();
		p2.setLayout(new BorderLayout());
		p2.add(p, BorderLayout.SOUTH);
		// create JLabel for statusBar with a border
		statusBar = new JLabel("Select Action");
		statusBar.setBorder(new BevelBorder(BevelBorder.LOWERED));
		setCopy("");
		getContentPane().add(p2, BorderLayout.CENTER);
		getContentPane().add(statusBar, BorderLayout.SOUTH);

		comp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				compression();
			}
		});
		uncomp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				unCompression();
			}
		});

	}

	public JMenuBar createMenuBar() {
		MenuListener menuListener = new MenuListener();

		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		JMenuItem aboutMenuItem = new JMenuItem("About...");
		aboutMenuItem.addActionListener(menuListener);
		aboutMenuItem.setEnabled(true);
		JMenuItem exitMenuItem = new JMenuItem("Exit");
		exitMenuItem.addActionListener(menuListener);
		fileMenu.addSeparator();
		fileMenu.add(aboutMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(exitMenuItem);
		JMenu compressMenu = new JMenu("Compression");
		compressMenuItem = new JMenuItem("Compress...");
		compressMenuItem.addActionListener(menuListener);
		compressMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F10,
				ActionEvent.CTRL_MASK));
		compressMenuItem.setEnabled(true);
		uncompressMenuItem = new JMenuItem("Uncompress...");
		uncompressMenuItem.addActionListener(menuListener);
		uncompressMenuItem.setAccelerator(KeyStroke.getKeyStroke(
				KeyEvent.VK_F11, ActionEvent.CTRL_MASK));
		compressMenu.add(compressMenuItem);
		compressMenu.add(uncompressMenuItem);
		JMenuBar bar = new JMenuBar();
		bar.add(fileMenu);
		bar.add(compressMenu);
		return bar;
	}

	public void compression() {
		int f = choose.showOpenDialog(MainHuffman.this);
		if (f == JFileChooser.APPROVE_OPTION) {
			file1 = choose.getSelectedFile();
			compress = new Compressor(file1);
			MainHuffman.this.setTitle("Compressing.....");
			statusBar.setText("Compressing in progress....");
			compress.compress();
			JOptionPane.showMessageDialog(null, compress.gethuffReport(),
					"Report", JOptionPane.INFORMATION_MESSAGE);
			MainHuffman.this.setTitle("Algorithm Course");
			statusBar.setText("Compression done succesfully");
		}

	}

	public void unCompression() {
		int f = choose.showOpenDialog(MainHuffman.this);
		if (f == JFileChooser.APPROVE_OPTION) {
			file2 = choose.getSelectedFile();
			uncompress = new Uncompress(file2);
			statusBar.setText("Decompressing in progress....");
			try {
				uncompress.decompress();
			} catch (HuffmanExeption ex) {
				System.out.println(ex.getMsg());
			}
			MainHuffman.this.setTitle(" Decompressing.....");
			JOptionPane.showMessageDialog(null, uncompress.gethuffReport(),
					"REPORT", JOptionPane.INFORMATION_MESSAGE);
			statusBar.setText("Decompressing done succesfully");
			MainHuffman.this.setTitle(" HUFFMAN PROGRAM ");
		}

	}

	public class MenuListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (event.getActionCommand().equals("About..."))
				aboutMenu();
			else if (event.getActionCommand().equals("Exit"))
				System.exit(0);
			else if (event.getActionCommand().equals("Compress..."))
				compression();
			else if (event.getActionCommand().equals("Uncompress..."))
				unCompression();
		}

	}

	public void aboutMenu() {
		String about = "HuffMan Codding Program"
				+ "\n By Weam Bader \n std ID no.1120230"
				+ "\nSecond assignment for Algorithm course"
				+ "\nInstructor Iyad Jaber";
		JOptionPane.showMessageDialog(null, about, "ABOUT",
				JOptionPane.INFORMATION_MESSAGE);
	}

	public void setExists(boolean exists) {
		this.exists = exists;
	}

	public boolean isExists() {
		return exists;
	}

	public void setCopy(String copy) {
		this.copy = copy;
	}

	public String getCopy() {
		return copy;
	}

	public static void main(String args[]) {
		MainHuffman huff1 = new MainHuffman();
		huff1.setSize(400, 400);
		huff1.setLocation(100, 100);
		huff1.setVisible(true);
		huff1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
