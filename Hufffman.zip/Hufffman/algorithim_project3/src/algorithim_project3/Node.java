/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithim_project3;

/**
 *
 * @author jamil
 */
// jamil isayyed 1080101
// jamil isayyed 1080101
public class Node implements Comparable ,Cloneable
{
	private int  count;
	private char ch;
	Node left;
	Node right;
	private String code;
	int n=0;
	 static String [] header = new String[256];
	 public Node()
	 {

	 }
	//for take the character and the count number of each char in the file when we do new node
	 public Node(int count,char ch)
	{
		this.count = count;
		this.ch=ch;
	}
	// for doing A node that have the sum of two nodes of the constructor above  in linking the
	// tree for having the path or the code for each char in the file
	public Node(Node left ,Node right,int count )
	{
		this.left = left;
		this.right = right;
		this.count = count;

	}
	//we use in the extract function in huffman class for the header when we want to do some
	//compare between more than bit or ...(bakml ba3deen)
	public Node (char ch,String code)
	{
		this.ch=ch;
		this.code=code;
	}



	public static String[] getHeader()
	{
		return header;
	}


	public void setCount(int x)
	{
		count = x;
	}
	public int getCount()
	{
		return count;
	}
	public void setCh(char ch)
	{
		this.ch=ch;
	}
	public char getCh()
	{
		return ch;
	}
	public int compareTo(Object n)
	{
		//System.out.println(this.toString()+"  this");

		Node x = (Node)n;
		//System.out.println(x.toString()+"  x");
		if(this.getCount()>x.getCount())
			return 1;
		else if(this.getCount()<x.getCount())
			return -1;
		else return 0;

	}
	public String toString()
	{
		return "char is "+this.getCh()+" count = "+this.getCount();
	}

	 public void printNode(String path)
     {
             if ((left==null) && (right==null))
                     System.out.println(this.getCh() + " " + path);

             if (left != null)
                     left.printNode(path + '0');
             if (right != null)
                     right.printNode(path + '1');
     }

	 public void printNodeHeader(String path)
     {
             if ((left==null) && (right==null)&&this.getCh()!=(char)0)
             {
                     //System.out.println(this.getCh() + " " + path);
                     header[(int)this.getCh()]=new String(path);
                   //  System.out.println("char is "+this.getCh()+" Path is "+path);
                    // System.out.println("header "+header[(int)this.getCh()]);
             }

             if (left != null)
                     left.printNodeHeader(path + "0");
             if (right != null)
                     right.printNodeHeader(path + "1");
     }

	/* public void printNodeHeader(int x)
     {
             if ((left==null) && (right==null)&&this.getCh()!=(char)0)
             {
                     //System.out.println(this.getCh() + " " + path);
                     header1[(int)this.getCh()]+=path;
             }

             if (left != null)
                     left.printNode(path + '0');
             if (right != null)
                     right.printNode(path + '1');
     }
	 */
	 public  void printHeader()
	 {
		 for(int i=0;i<header.length;i++)
                 {
			 if(header[i]!=null)
                         {
                             if(i==10)
                               System.out.println("char is Enter"+" i = "+i+" code = "+header[i]);
                             else if(i==13)
                                 System.out.println("char is lineFeed"+" i = "+i+" code = "+header[i]);
                             else
                                System.out.println("char is "+((char)i)+" i = "+i+" code = "+header[i]);


                         }
                }
	 }
         public static String printHeader1()
	 {
             String x = "";
		 for(int i=0;i<header.length;i++)
                 {
			 if(header[i]!=null)
                         {
                             if(i==10)
                               x+="char is Enter"+" i = "+i+" code = "+header[i]+" \n"+(char)10;
                             else if(i==13)
                               x+="char is lineFeed"+" i = "+i+" code = "+header[i]+" \n"+(char)10;
                             else
                                x+="char is "+((char)i)+" i = "+i+" code = "+header[i]+" \n"+(char)10;


                         }
                }
             return x;
	 }

	 public void setCode(String code)
	 {
		this.code=code;
	 }

	 public String printExtractHeader()
	 {
		// System.out.println("char is "+this.ch+" code is "+this.code);
		return "char is "+this.ch+" code is "+this.code;
	 }
	 public void printExtractHeaderTree()
	 {
		 if((this.left==null)&&(this.right==null))
			 System.out.println("char is "+this.ch+" code is "+this.code);

		 if(this.left!=null)
		 {
			 System.out.println("left");
			 this.left.printExtractHeaderTree();
		 }
		 if(this.right!=null)
		 {
			 System.out.println("right");
			 this.right.printExtractHeaderTree();
		 }


	 }
	 public String getCode()
	 {
		 return this.code;
	 }



}


