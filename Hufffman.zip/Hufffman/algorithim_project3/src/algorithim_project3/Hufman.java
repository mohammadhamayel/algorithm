/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithim_project3;

/**
 *
 * @author jamil
 */

//jamil isayyed
//1080101
//comp336 algorithim
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Hufman
{
	private int [] chr = new int[256];
	private Node[] node1,node2;
	private Node[] node;
	private Node[] heap;
	private Node compressFileHeader,compressFileHeader1 ;
	//private  String [] header1 = new String[256];
	private String inFileName,outFileName;
        private int numOfChar=0;
	// to count the char in the file
	public void countChar(File x) throws IOException
	{
		for(int i=0;i<chr.length;i++)
			chr[i]=0;
		inFileName=x.getAbsolutePath();
		//File file = new File(x);
		FileInputStream input = new FileInputStream(x);
		DataInputStream in = new DataInputStream(input);
		//byte[] b = new byte[4];
		int value;
		      while ((value = in.read()) != -1)
		      {
		    	  //System.out.println("value "+value);
		    	  chr[(int)value]++;
                          numOfChar++;
		    	 // for(int i=0;i<b.length;i++)
		    		//  System.out.println((char)b[i]+" char ");
		    	  //chr[(int)b[0]]++;
		    	  //chr[(int)b[1]]++;
		    	  //chr[(int)b[2]]++;
		    	  //chr[(int)b[3]]++;
		    	  //System.out.println(chr[10]+" char");
		      }
		      in.close();
		     /* for(int j=0;j<chr.length;j++)
		    	  if(chr[j]!=0)
		    	  System.out.println(chr[j]+" char j ="+j);*/
	}

	/*public void countChar(String x) throws IOException
	{
		for(int i=0;i<chr.length;i++)
			chr[i]=0;
		//File file = new File(x);
		FileInputStream input = new FileInputStream(x);
		byte[] b = new byte[4];
		int value;
		      while ((value = input.read(b)) != -1)
		      {
		    	 // for(int i=0;i<b.length;i++)
		    		//  System.out.println((char)b[i]+" char ");
		    	  chr[(int)b[0]]++;
		    	  chr[(int)b[1]]++;
		    	  chr[(int)b[2]]++;
		    	  chr[(int)b[3]]++;
		    	  //System.out.println(chr[10]+" char");
		      }
		      input.close();
		      for(int j=0;j<chr.length;j++)
		    	  if(chr[j]!=0)
		    	  System.out.println(chr[j]+" char j ="+j);
	}*/
		/*public void countChar(String x) throws FileNotFoundException
		{
			for(int i=0;i<chr.length;i++)
				chr[i]=0;
			File file = new File(x);
			Scanner scan = new Scanner(file);
			String a ="";
			while (scan.hasNextLine())
			{


				if(scan.hasNextLine())
				{
					//System.out.println("line + '\n'");
					a += scan.nextLine()+"\n";
					//System.out.println("a ln = "+a);
				}
				else
				{
					//System.out.println("line ");
					a+=scan.nextLine();
					//System.out.println("a  = "+a);
				}
				//System.out.println(a+ "jamil");
				//char[] ch= a.toCharArray();

				//a = scan.next();

				//chr[32]--;//space
			}
		for(int i=0;i<a.length();i++)
		{
			//System.out.println(ch[i]);
			//System.out.println((int)a.charAt(i)+" i = "+i);
			chr[(int)a.charAt(i)]++;

		}
	}*/
	// to do the tree to find the code of each char by using hufman algorithim
	public void buildHuffman()
	{
		//heapSort(node);

		 heap = new Node[node.length*2];/*****************************nakl 2l arrey la ma7l 2a5r mesh shart y3ml insert 3ashan y3ml delete****************************/
		  for(int j=0;j<node.length;j++)
			  heap[j+1]=node[j];
		 /* for(int i =0;i<heap.length;i++)
			  if(heap[i]!=null)
				System.out.println(heap[i].toString()+"TEST (build huffman) heap i = "+i);*/
		  int b =node.length-1;
		  for(int i=1;i<=b;i++)
		  {
			 /* for(int j =0;j<node.length;j++)
					System.out.println(node[j].toString()+"TEST (build huffman) node i = "+j);/***************************print statement*****************/
			  Node z ;
			  Node x = deleteMin();
			  //System.out.println(x.toString()+" left Size + i = "+i);
			  Node y = deleteMin();
			  //System.out.println(y.toString()+" right Size + i = "+i);
			  z = new Node(x,y,x.getCount()+y.getCount());
			  insert(z);
			  //System.out.println("z = "+z.toString());
			  int s=0;
			  for(int k= 0;k<heap.length;k++)
				  if(heap[k]!=null)
					  s++;
			  node2 = new Node[s];
			  int a=0;
			  for(int q=0;q<heap.length;q++)
			  {

				  if(heap[q]!=null)
				  {
					  node2[a]=heap[q];
				  		a++;
				  }
				  		//System.out.println("small arrey  "+n[a].toString());
			  }
			  //heapSort(node2);
			  /*for(int j=0;j<heap.length;j++)                                                   /****** print statements*********/
				 /* if(heap[j]!=null)
					  System.out.println(heap[j].toString()+"(build huffman) j heap before = "+j);*/
			  //quick(node2);
			  for(int j=0;j<heap.length;j++)
			  {
				  heap[j]=null;
			  }

			  for(int j=1;j<=node2.length;j++)
			  {
				  heap[j]=node2[j-1];
			  }
		  }
		  System.out.println("jamiL  hahahahaha good" );
	}
	public int[] getChr()
	{
		return chr;
	}
	//to creat nodes for each char in the file
	public void createNode()
	{
		int x=0;

		for(int i=0;i<chr.length;i++)
		{
			if(chr[i]!=0)
				x++;
		}

		node= new Node[x];
		System.out.println("node.length "+node.length);
		int j=0;
		for(int i=0;i<chr.length;i++)
		{
			if(chr[i]!=0&&j<x)
			{
				//System.out.println("i "+i +" chr[i] = "+chr[i]);
				node[j] = new Node(chr[i],(char)i) ;
				j++;
			}
		}
		node1=node;
		/*quick();
		for(int i=0;i<node.length;i++)
			System.out.println("char "+node[i].getCh()+" count "+node[i].getCount());
		System.out.println("quick....heap");*/
		heapSort(node1);
		for(int i=0;i<node1.length;i++)
			System.out.println(node1[i].toString()+ " create Node ");
		node=node1;

	}
	// heap sort
	public  void heapSort(Node[] node1) {
	    // Create a heap from the list
	    for (int i = 1; i < node1.length; i++) {
	      makeHeap( i);
	    }

	    // Produce a sorted array from the heap
	    for (int last = node1.length - 1; last > 0; ) {
	      // Swap list[0] with list[last]
	      Node temp = node1[last];
	      node1[last] = node1[0];
	      node1[0] = temp;
	      rebuildHeap( --last);
	    }
	  }

	  /** Assume list[0..k-1] is a heap, add list[k] to the heap */
	  private  void makeHeap( int k) {
	    int currentIndex = k;
	    while (currentIndex > 0 &&
	        node1[currentIndex].compareTo(node1[(currentIndex-1 ) / 2])>0 ) {
	      // Swap list[currentIndex] with list[(currentIndex - 1) / 2]
	      Node temp = node1[currentIndex];
	      node1[currentIndex] = node1[(currentIndex - 1) / 2];
	      node1[(currentIndex - 1) / 2] = temp;

	      currentIndex = (currentIndex - 1) / 2;
	    }
	  }
	  // to make sure that the sort is ok (ment heap)
	  private  void rebuildHeap( int last) {
	    int currentIndex = 0;
	    boolean isHeap = false;

	    while (!isHeap) {
	      int leftChildIndex = 2 * currentIndex + 1;
	      int rightChildIndex = 2 * currentIndex + 2;
	      int maxIndex = currentIndex;

	      if (leftChildIndex <= last &&
	        node1[maxIndex].compareTo(node1[leftChildIndex])<0) {
	        maxIndex = leftChildIndex;
	      }

	      if (rightChildIndex <= last &&
	        node1[maxIndex].compareTo(node1[rightChildIndex])<0) {
	        maxIndex = rightChildIndex;
	      }

	      if (maxIndex != currentIndex) {
	        // Swap list[currentIndex] with list[maxIndex]
	        Node temp = node1[currentIndex];
	        node1[currentIndex] = node1[maxIndex];
	        node1[maxIndex] = temp;
	        currentIndex = maxIndex;
	      } else {
	        isHeap = true;
	      }
	    }
	  }
	  // to insert in the tree by huffman algorithim
	  public void insert ( Node x)throws ArrayIndexOutOfBoundsException
	  {
		  int i;
		  System.out.println("(insert) node.length = "+node.length);

		  i=node.length+1;
		  if(isFull(heap)==true)
			  System.out.println("error:the heap is full ");
		  else
		  {
			  while(i>1&&heap[i/2].compareTo(x)>0)
			  {
				  heap[i]=heap[i/2];
				  i/=2;
			  }
			  heap[i]=x;
		  }

		  /*for(int j=0;j<heap.length;j++)
		  {
			  if(heap[j]!=null)
				  System.out.println(heap[j].toString()+"(insert) J  insert = "+j);



		  }*/
	  }
	  public boolean isFull(Node[] n)
		{
			for(int i=0;i<n.length;i++)
			{
				if(n[i]==null)
					return false;
			}
			return true;
		}
	  public Node[] getNode()
	  {
		  return node;
	  }
	  // to delete from the tree to find the min in huffman algorithim
	  public Node deleteMin()
	  {
		  int i,child;
		  Node minElement,lastElement;
		  minElement = null;//maybe error
		 // System.out.println(h[0].toString()+"jamil");
		  if(isEmpty(heap)!=true)
		  {
			  minElement = heap[1];
			  int size=0;
			  for(int j=0;j<heap.length;j++)
				  if(heap[j]!=null)
					  size++;
			  //System.out.println("(delete)Size = "+size);
			  lastElement=heap[size];

			  //System.out.println(heap[size].toString()+"(delete)jamil + last");

			  for(i=1;i*2<=size;i=child)
			  {
				  child=2*i;
				  if((child<size)&&heap[child+1].compareTo(heap[child])<0)
					  child++;
				  if(lastElement.compareTo(heap[child])>0)
					  heap[i]=heap[child];
				  else
					  break;
			  }
			  heap[i]=lastElement;
			  heap[size]=null;

			  int s=0;
			  for(int k= 0;k<heap.length;k++)
				  if(heap[k]!=null)
					  s++;
			  node2 = new Node[s];
			  //System.out.println("(delete)SSSS Size = "+node2.length);
			  int a=0;
			  for(int q=0;q<heap.length;q++)
			  {

				  if(heap[q]!=null)
				  {
					  node2[a]=heap[q];
				  		a++;
				  }
				  		//System.out.println("small arrey  "+n[a].toString());
			  }
			/*  for(int j=0;j<node2.length;j++)
			  {
				  System.out.println(node2[j]+" node 2 in delete TEST1  ");
			  }*/
			  //heapSort(node2);
			  node=node2;
			  /*for(int j=0;j<heap.length;j++)                                                   /****** print statements*********/
				 /* if(heap[j]!=null)
					  System.out.println(heap[j].toString()+"(delete) j heap before = "+j);*/
			  //quick(node2);
			  for(int j=0;j<heap.length;j++)
			  {
				  heap[j]=null;
			  }

			  for(int j=1;j<=node2.length;j++)
			  {
				  heap[j]=node2[j-1];
			  }

			  /*for(int j=0;j<heap.length;j++)                                                   /****** print statements*********/
				 /* if(heap[j]!=null)
					  System.out.println(heap[j].toString()+"(delete) j heap after = "+j);
			  System.out.println();
			  /*for(int j=0;j<node2.length;j++)
				  if(node2[j]!=null)
					  System.out.println(node2[j].toString()+" jn = "+j);*/

		  }
		  return minElement;

	  }
	private boolean isEmpty(Node[] h)
	{
		for(int i=0;i<h.length;i++)
		{
			if(h[i]!=null)
				return false;
		}

		return true;
	}
/*	public void getHeader()
	{
		for(int k=0;k<header1.length;k++)
			header1[k]=-1;
		int x=0;
		for(int i=0;i<Node.header.length;i++)
		{
			if(Node.header[i]!=null)
			{
				for(int j=0;j<Node.header[i].length();j++)
					x+=(Node.header[i].charAt(j)-48)*Math.pow(2, Node.header[i].length()-1-j);
				header1[i]=x;
				x=0;
			}
		}

	}

	public void printIntHeader()
	{
		for(int i=0;i<header1.length;i++)
			if(header1[i]!=-1)
			System.out.println("Char is "+(char)i+" i = "+i+" Path is in int "+header1[i]);
	}*/


	//to get 4 bytes and write 4 bytes
	public void compress1(String x) throws IOException
	{
		outFileName = x;
		FileOutputStream output = new FileOutputStream(x);
		DataOutputStream out = new DataOutputStream(output);
		String[] h = heap[1].getHeader();
		for(int i=0;i<h.length;i++)
			if(h[i]!=null)
			out.writeBytes(((char)i)+h[i]);
		System.out.println("Header DONE...................................................");
		out.writeBytes("\n");
		//System.out.println("jamil111");
		FileInputStream input = new FileInputStream(inFileName);
		DataInputStream in = new DataInputStream(input);
		int value;
		//value= in.read();
		//System.out.println(value);
		byte[] byte1 = new byte[4];
		int y=0;
		byte[] byte2 = new byte[4];
		for(int i=0;i<byte1.length;i++)
			byte1[i]=0;
		for(int i=0;i<byte2.length;i++)
			byte2[i]=0;
		while((value = in.read(byte2))!=-1 )
		{
			//for(int q=0;q<byte2.length;q++)
				//System.out.println("byte2["+q+"] = "+byte2[q]);
			int loc=0;
			for(int j=0;j<byte2.length;j++)
			{
				int chr = (int)byte2[j];

				if(h[chr]!=null)
				{
					//System.out.println(value);
					String code = h[chr];
					System.out.println("value = "+value);
					System.out.println("hvalue "+h[value]);

					for(int i=0;i<code.length();i++)
					{
						//System.out.println("y= "+y);
						if(code.charAt(i)-48==1)
						{
							if(y==31)
							{
								System.out.println("Byte inserted");
								out.write(byte1);
								y=0;
								loc=0;
								for(int k=0;k<byte1.length;k++)
									byte1[k]=0;
							}
						//	System.out.println("jamil compress bitloc = "+loc%8+" byteindex = "+loc/8+" loc = "+loc);
							int byteIndex = loc/8;
							int bitLoc = loc%8;
							byte1[byteIndex]= (byte) (byte1[byteIndex] | (1<<7-bitLoc));
							loc++;
							y++;
						}
						else
						{
							loc++;
							if(y==31)
							{
								System.out.println("Byte inserted");
								out.write(byte1);
								y=0;
								for(int k=0;k<byte1.length;k++)
									byte1[k]=0;
								loc=0;
							}
							else
								y++;;
						}
					}


				}
			}

		}
		out.write(byte1);
		out.close();
		in.close();
	}

	//write and read 1 byte (compressing)
	public void compress(File out1,File in1) throws IOException
	{
		outFileName =out1.getAbsolutePath();
		System.out.println("file output nsme is "+outFileName);
		FileOutputStream output = new FileOutputStream(out1);
		DataOutputStream out = new DataOutputStream(output);
		String[] h = heap[1].getHeader();
                heap[1].printNodeHeader("");
                heap[1].printHeader();
		for(int i=0;i<h.length;i++)
		{
			if(h[i]!=null)
			{
				if(i==10)
				{
					out.writeBytes(("en")+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				}
				else if(i==13)
				{
					out.writeBytes(("lf")+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				}
				else
				{
					out.writeBytes(((char)i)+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				}
			}
		}
		out.writeBytes("\n");
		System.out.println("HEADER DONE...........................................................................................");
		FileInputStream input = new FileInputStream(in1);
		System.out.println(" file that we read from it is "+inFileName);
		DataInputStream in = new DataInputStream(input);
		int value;
		//value= in.read();
		//System.out.println(value);
		byte byte1 = 0;
		int y=0;
		int loc=0;
		while((value = in.read())!=-1 )
		{
			//System.out.println("y " +y);
			//System.out.println("value = "+value);
			//System.out.println("hvalue "+h[value]);
			if(h[value]!=null)
			{
				//System.out.println(value);
				String code = h[value];


				for(int i=0;i<code.length();i++)
				{
					//System.out.println("y = "+y);
					if(code.charAt(i)-48==1)
					{
						if(y==7||y==14||y==21||y==28)
						{
							System.out.println("Byte inserted");
							out.writeByte(byte1);
							y=0;
							byte1=0;
						}
						//System.out.println("jamil compress loc  = "+loc+" bit loc = "+loc%8);
						int bitLoc = loc%8;
						byte1= (byte) (byte1 | (1<<7-bitLoc));
						loc++;
						y++;
					}
					else
					{
						//System.out.println("jamil bit =0 + y "+y);
						loc++;
						if(y==7||y==14||y==21||y==28)
						{
							System.out.println("Byte inserted");
							out.writeByte(byte1);
							y=0;
							byte1=0;
						}
						else
							y++;

					}

				}


			}

		}
		out.writeByte(byte1);
                System.out.println("jamil");
		out.close();
		in.close();




	}
	//@SuppressWarnings("deprecation")
	//@SuppressWarnings("deprecation")
	/***********************************************************************************extract**************************************/
	public void extract(String x) throws IOException
	{
		outFileName = x;
		Node[] temp1 = null,temp2 = null,header2 = null;
		DataInputStream in = new DataInputStream(new FileInputStream(outFileName));
		int z=0;
		for(;z<x.length();)
		{
			if(x.charAt(z)!='.')
				z++;
			else
				break;

		}
		System.out.println(x.substring(0, z));
		String file = new String(x.substring(0,z));
		System.out.println("file name is hh"+file);

		DataOutputStream out = new DataOutputStream(new FileOutputStream(file) );
		String s="";
		//int k=0;
		//while(((value=in.read())!=-1))
		//{
			s+= in.readLine();
			System.out.println("JAMIL READING");
		//}
		StringTokenizer tokens = new StringTokenizer(s," ");
		int countTokens = tokens.countTokens();
		System.out.println(countTokens+" count tokens");
		int i=1;
		int count=0;
		header2 = new Node[countTokens];
		while(tokens.hasMoreTokens()&&i<=countTokens)
		{
			String s1 = tokens.nextToken();
			if(s1.charAt(0)=='e'&&s1.charAt(1)=='n')
			{
				//header1[10]=s1.substring(2, s1.length());
				header2[count]=new Node((char)10,s1.substring(2,s1.length()));
				count++;
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>ENTER<<<<<<<<<<<<<<<<<<<<<<<");
				i++;
			}
			else if(s1.charAt(0)=='l'&&s1.charAt(1)=='f')
			{
				//header1[13]=s1.substring(2, s1.length());
				header2[count]=new Node((char)13,s1.substring(2,s1.length()));
				count++;
				i++;
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>LINE FEED<<<<<<<<<<<<<<<<<<<<<<<");
			}
			else
			{
				//header1[(int)s1.charAt(0)]=s1.substring(1, s1.length());
				header2[count]=new Node(s1.charAt(0),s1.substring(1,s1.length()));
				count++;
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				i++;
			}
		}

		//compressFileHeader.printExtractHeaderTree();
		compressFileHeader = new Node();
		for(int j=0;j<header2.length;j++)/****************************************************print statements *********************/
			//if(header2[j]!=null)
				System.out.println(header2[j].printExtractHeader()+"j = "+j);

		for(int j=0;j<header2.length;j++)
		{
			//header2[j].printExtractHeader();
			buildHeaderTree(this.compressFileHeader,header2[j],0);
			//System.out.println("code inserted tp the tree j = "+j);
			//compressFileHeader.printExtractHeaderTree();
		}
		System.out.println("JAMIL END END OF TREE hahahaha");
		//compressFileHeader.printExtractHeaderTree();
		//System.out.println(header1[10]+" header1[10]");
		//System.out.println(header1[13]+" header1[13]");
		byte b1=0,b2=0,b3=0 ;
		String path="";
		int loc=0,bitLoc=0,bit;
		int value,counter=0;
		Node n=compressFileHeader;
		boolean l=true;
		while((value = in.read())!=-1)
		{

			System.out.println("firstWhile");
			b1 = (byte)value;
			System.out.println("value =" +value);
			System.out.println("value = "+value);
			loc=0;
			count=0;
			while(count<8)
			{
				bitLoc=loc%8;
			bit = (byte)((byte)b1 & (1<<7-bitLoc));
			if(bit!=0)
				bit=1;
			//System.out.println("bit = "+bit);
			//if(counter!=7)
			{
				if(bit==0)
				{
					if(n.left==null && n.right == null)
					{
						System.out.println("write");
						out.write(n.getCh());
						n=compressFileHeader;
						count++;
					}
					else
					{
						n=n.left;
						count++;
						System.out.println("n.left");
						System.out.println(n.left);
						System.out.println(n.right);

					}
					if(n.left==null && n.right == null)
					{
						System.out.println("write");
						out.write(n.getCh());
						n=compressFileHeader;
						count++;
					}

				}
				else if(bit==1)
				{
					if(n.left==null && n.right == null)
					{
						System.out.println("write");
							out.write(n.getCh());
						n=compressFileHeader;
						count++;
					}
					else
					{
						n=n.right;
						count++;
						System.out.println("n.left");
					}

					{
						System.out.println("write");
						out.write(n.getCh());
						n=compressFileHeader;
						count++;
					}

				}
			}

			//else if(counter == 7)
			{
				//counter=0;

			}
			loc++;
			counter++;

			}
	}
	out.close();
}


/*	public void extract1(String x) throws IOException  /******************test*****************/
	/*{
		outFileName = x;
		DataInputStream in = new DataInputStream(new FileInputStream(outFileName));
		int value;
		String s="";
		int count=0;
		String h="";
		char b = 0,c = 0;
		while(((value=in.read())!=-1))
		{
			s+=(char)value+in.readLine();
			System.out.println("s =  "+s);

			for(int i=0;i<s.length();i++)
			{
				if(s.charAt(i)=='e'&&s.charAt(i+1)=='d'&&s.charAt(i+2)=='d')
				{
					count=i;
					h=s.substring(0, i);
					System.out.println("header = "+h);
					break;
				}
				//else
				//{
					//System.out.println(value);
					//s+=(char)value ;
					//count++;
					//System.out.println(b);
					//s+=(char)b;
					//count++;
					//System.out.println(c);
					//s+=(char)c;
					//count++;
				//}
			}
			//s+=(char)value ;
			//count++;
			//System.out.println("JAMIL READING");
		}
		StringTokenizer tokens = new StringTokenizer(h," ");
		int countTokens = tokens.countTokens();
		int i=0;
		while(tokens.hasMoreTokens()&&i<countTokens-2)
		{

			String s1 = tokens.nextToken();
			System.out.println("token is "+s1);
			if(s1.charAt(0)=='e'&&s1.charAt(1)=='n')
			{
				header1[10]=s1.substring(2, s1.length());
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>ENTER<<<<<<<<<<<<<<<<<<<<<<<");
			}
			else if(s1.charAt(0)=='l'&&s1.charAt(1)=='f')
			{
				header1[13]=s1.substring(2, s1.length());
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				System.out.println(">>>>>>>>>>>>>>>>>>>>>LINE FEED<<<<<<<<<<<<<<<<<<<<<<<");
			}
			else
			{
				header1[(int)s1.charAt(0)]=s1.substring(1, s1.length());
				System.out.println("(int)s1.charAt(0) "+(int)s1.charAt(0));
				System.out.println("(extract)token = s1 "+s1);
				i++;
			}
		}
		for(int j=0;j<header1.length;j++)/****************************************************print statements *********************/
			/*if(header1[j]!=null)
				System.out.println("char is header["+j+"] "+(char)j+" path is "+header1[j]);
		System.out.println(header1[10]+" header1[10]");
		System.out.println(header1[13]+" header1[13]");
	}

	public void compress2(String x) throws IOException/******************test*****************/
	/*{
		outFileName =x;
		System.out.println("file output nsme is "+outFileName);
		FileOutputStream output = new FileOutputStream(x);
		DataOutputStream out = new DataOutputStream(output);
		String[] h = heap[1].getHeader();
		for(int i=0;i<h.length;i++)
		{
			if(h[i]!=null)
			{
				if(i==10)
				{
					out.writeBytes(("en")+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				//}
				/*else if(i==13)
				{
					out.writeBytes(("lf")+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				/*}
				else
				{
					out.writeBytes(((char)i)+h[i]+" ");
					System.out.println(((char)i)+h[i]);/****************************print*****************/
				/*}
			}
		}
		out.writeBytes("end");
		System.out.println("HEADER DONE...........................................................................................");
		FileInputStream input = new FileInputStream(inFileName);
		System.out.println(" file that we read from it is "+inFileName);
		DataInputStream in = new DataInputStream(input);
		int value;
		//value= in.read();
		//System.out.println(value);
		byte byte1 = 0;
		int y=0;
		int loc=0;
		while((value = in.read())!=-1 )
		{
			//System.out.println("y " +y);
			//System.out.println("value = "+value);
			//System.out.println("hvalue "+h[value]);
			if(h[value]!=null)
			{
				//System.out.println(value);
				String code = h[value];


				for(int i=0;i<code.length();i++)
				{
					//System.out.println("y = "+y);
					if(code.charAt(i)-48==1)
					{
						if(y==7||y==14||y==21||y==28)
						{
							System.out.println("Byte inserted");
							out.writeByte(byte1);
							y=0;
							byte1=0;
						}
						//System.out.println("jamil compress loc  = "+loc+" bit loc = "+loc%8);
						int bitLoc = loc%8;
						byte1= (byte) (byte1 | (1<<7-bitLoc));
						loc++;
						y++;
					}
					else
					{
						//System.out.println("jamil bit =0 + y "+y);
						loc++;
						if(y==7||y==14||y==21||y==28)
						{
							System.out.println("Byte inserted");
							out.writeByte(byte1);
							y=0;
							byte1=0;
						}
						else
							y++;

					}

				}


			}

		}
		out.writeByte(byte1);
		out.close();
		in.close();




	}*/

	private void buildHeaderTree(Node root,Node x, int i)
	{
		if(i!=x.getCode().length())
		{
			//System.out.println("code is "+x.getCode()+" code.length =  "+x.getCode().length()+" i= "+i);
			if(x.getCode().charAt(i)=='0'&&root.left!=null)
			{
				//System.out.println("code is "+x.getCode()+" code.length =  "+x.getCode().length()+" i= "+i);
				//System.out.println("code.charAt(i)=='0'&&root.left!=null");
				buildHeaderTree(root.left,x,++i);

			}
			else if(x.getCode().charAt(i)=='0'&&root.left==null)
			{
				//System.out.println("code is "+x.getCode()+" code.length =  "+x.getCode().length()+" i= "+i);
				//System.out.println("code.charAt(i)=='0'&&root.left==null");
				root.left= new Node();
				buildHeaderTree(root.left,x,++i);

			}
			else if(x.getCode().charAt(i)=='1'&&root.right!=null)
			{
				//System.out.println("code is "+x.getCode()+" code.length =  "+x.getCode().length()+" i= "+i);
				//System.out.println("code.charAt(i)=='1'&&root.right!=null");
				buildHeaderTree(root.right,x,++i);

			}
			else if(x.getCode().charAt(i)=='1'&&root.right==null)
			{
				//System.out.println("code is "+x.getCode()+" code.length =  "+x.getCode().length()+" i= "+i);
				//System.out.println("code.charAt(i)=='1'&&root.right==null");
				root.right= new Node();
				buildHeaderTree(root.right,x,++i);

			}

		}
		else
		{
			root.setCh(x.getCh());
			root.setCode(x.getCode());
		}

	}

	public Node[] getHeap()
	{
		return heap;
	}

    public int getNumOfChar()
    {
        return numOfChar;
    }


}
