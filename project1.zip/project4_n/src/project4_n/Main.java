/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package project4_n;

import javax.swing.JButton;

/**
 *
 * @author Fadi Khalil
 */
public class Main extends javax.swing.JFrame{

    /**
     * @param args the command line arguments
     */

    public int xx=0;
    public int yy=0;

     public static int mm=9;//number of moves
    int[][] m1 = new int[][] {{0,0},{2,1},{1,2},{-1,2},{-2,1},{-2,-1},{-1,-2},{1,-2},{2,-1},{0,0}};
    //public int[][] m2 = new int[20][2];//new moves

        private int[] y = {0,2,1,-1,-2,-2,-1,1,2};
        private int[] x = {0,-1,-2,-2,-1,1,2,2,1};


    //public int[][] m=m1;
    public static int[][] m=new int[][] {{0,0},{2,1},{1,2},{-1,2},{-2,1},{-2,-1},{-1,-2},{1,-2},{2,-1},{0,0}};


    public int s = 8;//size of board
    JButton[][] bt = new JButton[s][s];//the buttons
    public static int sum =0;
    public static int dell =0;





    public static void main(String[] args) {
        // TODO code application logic here
    }

}
