
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Fadi Khalil
 */
public class main extends JFrame{



    File file;
    String s;
 protected void onBrowseSwing() throws Exception {

        JFileChooser fileChooser = new JFileChooser();

        int result = fileChooser.showDialog(null, "Open");
        if (result == JFileChooser.APPROVE_OPTION) {
            file = fileChooser.getSelectedFile();
            if(file.exists()){
            	s = file.getAbsolutePath();
            	//list = readFromFile(s);
            }
        }

    }

}
