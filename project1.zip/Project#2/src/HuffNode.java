
import java.io.*;
public class HuffNode implements Serializable, Comparable
{
  protected HuffNode right;
  protected HuffNode left;
  protected HuffNode parent;
  protected int frequency;
  protected int value;
  public HuffNode()
  {
    this(0, 0, null, null, null);
  }
  public HuffNode(int frequency,int value,HuffNode left,
                     HuffNode right,HuffNode parent)
  {

    this.frequency = frequency;
    this.value = value;
    this.left = left;
    this.right = right;
    this.parent = parent;
  }
 public int getFrequency()
  {
    return frequency;
  }

  public int getValue()
  {
    return value;
  }

 public int compareTo(Object obj)
  {
    if(obj instanceof HuffNode)
    {
      HuffNode compared = (HuffNode) obj;
      if (frequency < compared.frequency)
        return -1;
      else if (frequency > compared.frequency)
        return 1;
    }
    return 0;
  }

  public boolean isLeaf() {
        return (left == null && right == null);
    }
  public String toString()
  {
    String nodeStr = "frequency = [   " + frequency + " ]";
    return nodeStr;
  }



}
