

import java.io.*;
import javax.swing.JOptionPane;


class Table implements Serializable, HuffConstants
{
  private String FileName;
  private int fileSize;
  private int arrayChars[], size = 0, front = 0;//siz is size of array
  public Table(int fileSize,String FileName)
  {
    arrayChars = new int[DIFF_BYTES];
    this.FileName = FileName;
    this.fileSize = fileSize;
  }
  public void push(int c)//to fill the arrayChars of freqyncy of evry bi ( to make arrayChar==freq)
  {
    if(size > DIFF_BYTES)//if arraychars is full
      System.out.println("ERROR");
    arrayChars[size] = c;
    size++;
  }
  
  public int originalSize()
  {
    return fileSize;
  }
  public int pop()
  {
    if(size < 1)//the size is zero and arraychars is empty
      System.out.println("ERROR");
    int p = arrayChars[front++];//we use front, cuse it zero and we need to,take element and another from the first
    size--;
    return p;
  }

  public String fileName()
  {
    return FileName;
  }
  public void report(String report)
  {
    JOptionPane.showMessageDialog(null,report,"REPORT",
                                  JOptionPane.INFORMATION_MESSAGE);
  }
}
