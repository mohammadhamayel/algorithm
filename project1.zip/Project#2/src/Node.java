
public class Node//  A general node to be used for implementation of priority queue
{
  private Node next;
  private Node previous;
  private HuffNode element;
 public Node()
  {
    this(null, null, null);
  }
  public Node(Node next,Node prev,HuffNode element)
  {
    this.next = next;
    this.previous = prev;
    this.element = element;
  }
 public void setNext(Node n)
 {
   next = n;
 }
  public Node getNext()
  {
    return next;
  }
 public void setPrevious(Node n)
 {
   previous = n;
 }
  public Node getPrevious()
  {
    return previous;
  }
  public void setElement(HuffNode huffNode)
  {
    this.element = huffNode;
  }
  public HuffNode getElement()
  {
    return element;
  }
}
