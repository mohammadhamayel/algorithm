
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mass
 */

public class connection {
    static Statement stmt;
    private ResultSet RS;
     public static void con(){
       try {
        
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (Exception ex) {
            
            ex.printStackTrace();

            
        }
        
        
        try {
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/insure_company", "root", "majd");
            
            
            // Do something with the Connection
            Statement stmt = null;
            ResultSet rs = null;
            stmt = (Statement) conn.createStatement();
           rs = (ResultSet) stmt.executeQuery("SELECT * FROM Agent ");
           
        
            int numCols = rs.getMetaData().getColumnCount ();
            

            while ( rs.next() ) {
             
                       
                     for (int i=1; i<=numCols; i++) {
                        String sr = rs.getString(i);
                       
                        


                                        
              }  // end for
            
            }  // end while

        } catch (SQLException ex) {
            // handle any errors
        System.out.println("SQLException: " + ex.getMessage());
        System.out.println("SQLState: " + ex.getSQLState());
        System.out.println("VendorError: " + ex.getErrorCode());
        }
     }

    java.sql.ResultSet AgentSearch(String s) {
         try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM Agent where A_id = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
    }

    java.sql.ResultSet cusSearch(String s) {
        try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM customer  where c_id = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
            }

    java.sql.ResultSet carSearch(String s) {
      try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM car_insurance ci where car_id = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
            
    }

    java.sql.ResultSet hSearch(String s) {
       try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM home_insuranc hi where home_id = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
    }

    java.sql.ResultSet BillSearch(String s) {
try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM Bill b where cuid = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
    }

    java.sql.ResultSet paySearch(String s) {
       try {
	     RS=(ResultSet) stmt.executeQuery("SELECT * FROM payment pay where cuid = \""+s+"\";");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return RS;
    }

    java.sql.ResultSet supSearch(String name) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

 
}
